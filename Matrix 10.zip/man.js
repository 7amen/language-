/*
function zr2(){
document.
getElementById('zr2').style.background='red';
}
*/

function font15(){
	document.body.style.fontSize='15px'
}
function font25(){
	document.body.style.fontSize='20px'
}
function font40(){
	document.body.style.fontSize='40px'
}
function pc(){
	document.body.style.footer
	='center '
	document.body.style.fontSize='44px'
	document.body.style.margin='0px'
	document.body.style.padding='50px'
	

var ol=
document.getElementById("ol").style.fontSize='90px'
//const footer=
//document.getElementById('footer'//).style.textAlign='center';
var footer=document.getElementById ('footer').style.padding='190px'

	
}
